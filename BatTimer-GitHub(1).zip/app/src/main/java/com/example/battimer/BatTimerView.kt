package com.example.battimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.core.graphics.PathParser
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Bat emblem as SVG path data (viewBox 200x100, visible area roughly x 8..192, y 10..94). */
object BatShape {
    const val PATH =
        "M99.7,30 L104,30 L107,10 L112,28 C130,22 160,22 192,30 C186,42 182,52 178,64 " +
            "C170,56 162,56 154,66 C146,58 136,60 128,72 C120,62 112,64 106,80 L99.7,94 Z " +
            "M100.3,30 L96,30 L93,10 L88,28 C70,22 40,22 8,30 C14,42 18,52 22,64 " +
            "C30,56 38,56 46,66 C54,58 64,60 72,72 C80,62 88,64 94,80 L100.3,94 Z"
}

/**
 * The hero of the app: a Gotham-style countdown ring with a glowing Bat-Signal.
 * Everything is drawn on the GPU-accelerated canvas in a single frame loop, and the ring
 * is eased toward its target every frame so it always moves smoothly.
 */
class BatTimerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var store: TimerStore? = null
    var onStateChanged: (() -> Unit)? = null

    private val yellow = 0xFFFFD400.toInt()
    private val amber = 0xFFFFB300.toInt()
    private val white = 0xFFF2F2F2.toInt()

    private val batPath: Path = PathParser.createPathFromPathData(BatShape.PATH)
    private val shapePath = Path()
    private val shapeMatrix = Matrix()
    private val arcRect = RectF()
    private val ovalRect = RectF()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF23232C.toInt()
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = yellow
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = yellow
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val signalGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = yellow }
    private val signalPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0A0F.toInt() }
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        fontFeatureSettings = "tnum"
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.3f
    }

    private var cx = 0f
    private var cy = 0f
    private var radius = 0f
    private var strokeW = 0f
    private var ecy = 0f
    private var erx = 0f
    private var ery = 0f

    private var shown = 0f              // eased fraction currently drawn (starts at 0 -> intro sweep)
    private var lastFrame = 0L
    private var lastState: TState? = null
    private var doneAt = 0L
    private var lastSecs = -1
    private var cachedText = ""
    private val t0 = SystemClock.uptimeMillis()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f * 0.74f
        strokeW = radius * 0.085f
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        trackPaint.strokeWidth = strokeW
        pulsePaint.strokeWidth = strokeW
        arcPaint.strokeWidth = strokeW
        tickPaint.strokeWidth = max(2f, strokeW * 0.16f)

        bgPaint.shader = RadialGradient(
            cx, cy, max(w, h) * 0.75f,
            intArrayOf(0xFF1C1C26.toInt(), 0xFF09090D.toInt()), null, Shader.TileMode.CLAMP
        )
        haloPaint.shader = RadialGradient(
            cx, cy, radius * 1.35f,
            intArrayOf(0x66FFD400, 0x00FFD400), null, Shader.TileMode.CLAMP
        )
        val sweep = SweepGradient(
            cx, cy,
            intArrayOf(amber, yellow, 0xFFFFF0A0.toInt(), yellow, amber), null
        )
        sweep.setLocalMatrix(Matrix().apply { postRotate(-90f, cx, cy) })
        arcPaint.shader = sweep

        erx = radius * 0.46f
        ery = radius * 0.29f
        ecy = cy - radius * 0.30f
        signalPaint.shader = RadialGradient(
            cx, ecy, erx,
            intArrayOf(0xFFFFF3A0.toInt(), yellow, amber), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        labelPaint.textSize = radius * 0.075f
    }

    override fun onDetachedFromWindow() {
        lastFrame = 0L
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else (now - lastFrame).coerceIn(0L, 64L) / 1000f
        lastFrame = now
        val t = (now - t0) / 1000f

        // ---- read state --------------------------------------------------------------------
        val s = store
        var st = TState.IDLE
        var total = 1L
        var rem = 0L
        if (s != null) {
            if (s.state == TState.RUNNING && s.remainingMs() <= 0L) {
                s.finish()
                TimerActions.refreshWidgets(context)
            }
            st = s.state
            total = max(1L, s.totalMs)
            rem = s.remainingMs()
        }
        if (st != lastState) {
            if (st == TState.DONE && lastState != null) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                doneAt = now
            }
            lastState = st
            post { onStateChanged?.invoke() }
        }

        // ---- smooth easing toward the true fraction ----------------------------------------
        val target = (rem.toFloat() / total).coerceIn(0f, 1f)
        shown += (target - shown) * (1f - exp(-dt * 9f))

        val breathe = 0.5f + 0.5f * sin(t * if (st == TState.RUNNING) 2.4f else 1.2f)
        val blink = if (st == TState.DONE) 0.5f + 0.5f * sin(t * 9f) else 0f

        // ---- background + halo -------------------------------------------------------------
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        haloPaint.alpha = (90f + 80f * breathe + 80f * blink).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, radius * 1.35f, haloPaint)

        // ---- ticks (60, lit = time still remaining) ----------------------------------------
        val r1 = radius + strokeW * 1.05f
        for (i in 0 until 60) {
            val major = i % 5 == 0
            val len = strokeW * if (major) 0.95f else 0.5f
            val a = Math.toRadians(-90.0 + i * 6.0)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val lit = shown > 0.002f && (i / 60f) >= (1f - shown) - 0.001f
            if (lit) {
                tickPaint.color = yellow
                tickPaint.alpha = if (major) 255 else 170
            } else {
                tickPaint.color = 0xFF3A3A46.toInt()
                tickPaint.alpha = if (major) 200 else 120
            }
            canvas.drawLine(
                cx + ca * r1, cy + sa * r1,
                cx + ca * (r1 + len), cy + sa * (r1 + len), tickPaint
            )
        }

        // ---- track (blinks yellow when time is up) -----------------------------------------
        canvas.drawCircle(cx, cy, radius, trackPaint)
        if (st == TState.DONE) {
            pulsePaint.alpha = (60f + 195f * blink).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, radius, pulsePaint)
        }

        // ---- progress arc with soft glow ---------------------------------------------------
        if (shown > 0.002f) {
            val start = -90f + (1f - shown) * 360f
            val sweepAngle = shown * 360f
            glowPaint.strokeWidth = strokeW * 2.6f
            glowPaint.alpha = 22
            canvas.drawArc(arcRect, start, sweepAngle, false, glowPaint)
            glowPaint.strokeWidth = strokeW * 1.8f
            glowPaint.alpha = 40
            canvas.drawArc(arcRect, start, sweepAngle, false, glowPaint)
            canvas.drawArc(arcRect, start, sweepAngle, false, arcPaint)

            // glowing head where the ring is being "eaten"
            val ha = Math.toRadians(start.toDouble())
            val hx = cx + radius * cos(ha).toFloat()
            val hy = cy + radius * sin(ha).toFloat()
            headPaint.color = yellow
            headPaint.alpha = 80
            canvas.drawCircle(hx, hy, strokeW * (1.3f + 0.25f * breathe), headPaint)
            headPaint.color = white
            headPaint.alpha = 255
            canvas.drawCircle(hx, hy, strokeW * 0.5f, headPaint)
        }

        // ---- Bat-Signal --------------------------------------------------------------------
        val hover = sin(t * 1.6f) * radius * 0.008f
        val shake = if (st == TState.DONE) {
            val age = (now - doneAt) / 1000f
            if (age < 2f) sin(age * 40f) * 5f * (1f - age / 2f) else sin(t * 7f) * 2f
        } else 0f

        canvas.save()
        canvas.rotate(shake, cx, ecy + hover)
        for (k in 3 downTo 1) {
            val grow = radius * 0.045f * k
            ovalRect.set(
                cx - erx - grow, ecy + hover - ery - grow,
                cx + erx + grow, ecy + hover + ery + grow
            )
            signalGlowPaint.alpha = ((14 - k * 3) + 18 * breathe + 40 * blink).toInt().coerceIn(0, 255)
            canvas.drawOval(ovalRect, signalGlowPaint)
        }
        ovalRect.set(cx - erx, ecy + hover - ery, cx + erx, ecy + hover + ery)
        signalPaint.alpha = (225f + 30f * breathe - 70f * blink).toInt().coerceIn(0, 255)
        canvas.save()
        canvas.translate(0f, hover)
        ovalRect.set(cx - erx, ecy - ery, cx + erx, ecy + ery)
        canvas.drawOval(ovalRect, signalPaint)

        val sc = (erx * 2f * 0.74f) / 184f
        shapeMatrix.reset()
        shapeMatrix.postTranslate(-100f, -52f)
        shapeMatrix.postScale(sc, sc)
        shapeMatrix.postTranslate(cx, ecy)
        batPath.transform(shapeMatrix, shapePath)
        canvas.drawPath(shapePath, logoPaint)
        canvas.restore()
        canvas.restore()

        // ---- time + label ------------------------------------------------------------------
        val secs = ((rem + 999L) / 1000L).toInt()
        if (secs != lastSecs) {
            lastSecs = secs
            cachedText = format(secs)
        }
        timePaint.textSize = radius * 0.34f
        val maxW = radius * 1.55f
        val w = timePaint.measureText(cachedText)
        if (w > maxW) timePaint.textSize = timePaint.textSize * maxW / w
        timePaint.color = when {
            st == TState.DONE -> if (blink > 0.5f) yellow else white
            st == TState.RUNNING && secs <= 10 -> yellow
            else -> white
        }
        canvas.drawText(cachedText, cx, cy + radius * 0.40f, timePaint)

        labelPaint.color = if (st == TState.DONE) yellow else 0xFF8A8A96.toInt()
        val label = when (st) {
            TState.IDLE -> "READY"
            TState.RUNNING -> "ON PATROL"
            TState.PAUSED -> "STANDBY"
            TState.DONE -> "TIME'S UP"
        }
        canvas.drawText(label, cx, cy + radius * 0.66f, labelPaint)

        postInvalidateOnAnimation()
    }

    private fun format(sec: Int): String {
        val d = sec / 86400
        val h = (sec % 86400) / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return when {
            d > 0 -> "%dd %02d:%02d:%02d".format(d, h, m, s)
            h > 0 -> "%d:%02d:%02d".format(h, m, s)
            else -> "%02d:%02d".format(m, s)
        }
    }
}
