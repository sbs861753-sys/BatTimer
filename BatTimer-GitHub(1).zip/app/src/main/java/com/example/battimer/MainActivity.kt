package com.example.battimer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: TimerStore
    private lateinit var timerView: BatTimerView
    private lateinit var btnStart: TextView
    private lateinit var chips: List<Pair<TextView, Long>>

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = TimerStore.get(this)
        timerView = findViewById(R.id.timer_view)
        btnStart = findViewById(R.id.btn_start)

        timerView.store = store
        timerView.onStateChanged = { refreshUi() }
        timerView.setOnClickListener { toggle(it) }
        btnStart.setOnClickListener { toggle(it) }

        findViewById<View>(R.id.btn_reset).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            TimerActions.reset(this)
            refreshUi()
        }
        findViewById<View>(R.id.btn_set).setOnClickListener { showSetDialog() }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        chips = listOf(
            R.id.chip_1 to 60L,
            R.id.chip_5 to 300L,
            R.id.chip_10 to 600L,
            R.id.chip_25 to 1500L,
            R.id.chip_60 to 3600L
        ).map { (id, sec) -> findViewById<TextView>(id) to sec * 1000L }

        chips.forEach { (view, ms) ->
            view.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                TimerActions.setTotal(this, ms)
                refreshUi()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        TimerActions.refreshWidgets(this)
        refreshUi()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 500)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun toggle(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        if (store.state == TState.DONE && AlarmService.ringing) {
            // First tap only silences the alarm; the next tap restarts the timer.
            AlarmService.stop(this)
            TimerActions.cancelNotification(this)
        } else {
            TimerActions.toggle(this)
        }
        refreshUi()
    }

    private fun refreshUi() {
        btnStart.text = when (store.state) {
            TState.IDLE -> "START"
            TState.RUNNING -> "PAUSE"
            TState.PAUSED -> "RESUME"
            TState.DONE -> if (AlarmService.ringing) "STOP ALARM" else "RESTART"
        }
        chips.forEach { (view, ms) -> view.isSelected = ms == store.totalMs }

        val keepOn = store.state == TState.RUNNING && Settings.get(this).keepAwake
        if (keepOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun showSetDialog() {
        val sec = (store.totalMs / 1000L).toInt()

        fun picker(max: Int, value: Int) = NumberPicker(this).apply {
            minValue = 0
            maxValue = max
            this.value = value
            wrapSelectorWheel = true
            setFormatter { "%02d".format(it) }
        }

        val d = picker(99, sec / 86400)
        val h = picker(23, (sec % 86400) / 3600)
        val m = picker(59, (sec % 3600) / 60)
        val s = picker(59, sec % 60)

        fun column(p: NumberPicker, label: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(p)
            addView(TextView(context).apply {
                text = label
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(0xFF8A8A96.toInt())
            })
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val pad = (12 * resources.displayMetrics.density).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad / 2)
            addView(column(d, "DAYS"))
            addView(column(h, "HOURS"))
            addView(column(m, "MINUTES"))
            addView(column(s, "SECONDS"))
        }

        AlertDialog.Builder(this, R.style.BatDialog)
            .setTitle("Set countdown")
            .setView(row)
            .setPositiveButton("SET") { _, _ ->
                val total = d.value * 86400L + h.value * 3600L + m.value * 60L + s.value
                if (total <= 0L) {
                    Toast.makeText(this, "Pick a time above zero", Toast.LENGTH_SHORT).show()
                } else {
                    TimerActions.setTotal(this, total * 1000L)
                    refreshUi()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }
}
