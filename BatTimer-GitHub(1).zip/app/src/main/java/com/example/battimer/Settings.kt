package com.example.battimer

import android.content.Context

/** User options, saved on the phone. */
class Settings private constructor(ctx: Context) {

    private val p = ctx.getSharedPreferences("bat_settings", Context.MODE_PRIVATE)

    /** null = use the phone's default alarm sound. */
    var soundUri: String?
        get() = p.getString("sound_uri", null)
        set(v) { p.edit().putString("sound_uri", v).apply() }

    var soundName: String
        get() = p.getString("sound_name", null) ?: "Default alarm"
        set(v) { p.edit().putString("sound_name", v).apply() }

    /** How long the alarm rings, in seconds. 0 = until the user stops it. */
    var ringSeconds: Int
        get() = p.getInt("ring_secs", 60)
        set(v) { p.edit().putInt("ring_secs", v).apply() }

    /** 10..100 (percent of the phone's alarm volume). */
    var volume: Int
        get() = p.getInt("volume", 100)
        set(v) { p.edit().putInt("volume", v).apply() }

    var fadeIn: Boolean
        get() = p.getBoolean("fade_in", true)
        set(v) { p.edit().putBoolean("fade_in", v).apply() }

    var vibrate: Boolean
        get() = p.getBoolean("vibrate", true)
        set(v) { p.edit().putBoolean("vibrate", v).apply() }

    /** Blink the phone's torch like a Bat-Signal while the alarm rings. */
    var flash: Boolean
        get() = p.getBoolean("flash", false)
        set(v) { p.edit().putBoolean("flash", v).apply() }

    var keepAwake: Boolean
        get() = p.getBoolean("keep_awake", true)
        set(v) { p.edit().putBoolean("keep_awake", v).apply() }

    var snoozeMin: Int
        get() = p.getInt("snooze_min", 5)
        set(v) { p.edit().putInt("snooze_min", v).apply() }

    fun resetAll() {
        p.edit().clear().apply()
    }

    companion object {
        fun get(ctx: Context): Settings = Settings(ctx.applicationContext)
    }
}
