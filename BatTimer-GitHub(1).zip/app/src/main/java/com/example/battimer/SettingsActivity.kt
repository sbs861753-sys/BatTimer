package com.example.battimer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var st: Settings
    private lateinit var soundSub: TextView
    private lateinit var ringSub: TextView
    private lateinit var snoozeSub: TextView
    private lateinit var volLabel: TextView

    private val yellow = 0xFFFFD400.toInt()
    private val white = 0xFFF2F2F2.toInt()
    private val muted = 0xFF8A8A96.toInt()

    private val ringValues = intArrayOf(10, 30, 60, 120, 300, 0)
    private val ringLabels =
        arrayOf("10 seconds", "30 seconds", "1 minute", "2 minutes", "5 minutes", "Until I stop it")
    private val snoozeValues = intArrayOf(1, 5, 10, 15)
    private val snoozeLabels = arrayOf("1 minute", "5 minutes", "10 minutes", "15 minutes")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = Settings.get(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, dp(32))

        col.addView(header())

        // ---------------- ALARM ----------------
        col.addView(section("ALARM"))

        soundSub = subText(st.soundName)
        col.addView(clickRow("Alarm sound", soundSub) {
            choose(
                "Alarm sound",
                arrayOf("Default alarm", "Pick a ringtone", "Pick a music file from your phone"),
                -1
            ) { which ->
                when (which) {
                    0 -> {
                        st.soundUri = null
                        st.soundName = "Default alarm"
                        soundSub.text = "Default alarm"
                    }
                    1 -> pickRingtone()
                    2 -> pickFile()
                }
            }
        })

        col.addView(clickRow("Test alarm", subText("Plays your sound for a few seconds")) {
            try {
                AlarmService.start(this, true)
            } catch (e: Exception) {
                toast("Could not start the test")
            }
        })

        ringSub = subText(ringLabels[indexOf(ringValues, st.ringSeconds, 2)])
        col.addView(clickRow("Ring for", ringSub) {
            choose("Ring for", ringLabels, indexOf(ringValues, st.ringSeconds, 2)) { which ->
                st.ringSeconds = ringValues[which]
                ringSub.text = ringLabels[which]
            }
        })

        col.addView(volumeRow())

        col.addView(
            switchRow("Gentle fade-in", "Alarm volume rises slowly over 6 seconds", st.fadeIn) {
                st.fadeIn = it
            }
        )
        col.addView(switchRow("Vibrate", "Vibrate while the alarm rings", st.vibrate) {
            st.vibrate = it
        })
        col.addView(
            switchRow("Bat-Signal flash", "Blink the phone torch while the alarm rings", st.flash) {
                st.flash = it
            }
        )

        snoozeSub = subText("The +" + st.snoozeMin + " MIN button on the alarm adds this much time")
        col.addView(clickRow("Snooze length", snoozeSub) {
            choose("Snooze length", snoozeLabels, indexOf(snoozeValues, st.snoozeMin, 1)) { which ->
                st.snoozeMin = snoozeValues[which]
                snoozeSub.text = "The +" + st.snoozeMin + " MIN button on the alarm adds this much time"
            }
        })

        // ---------------- TIMER ----------------
        col.addView(section("TIMER"))
        col.addView(
            switchRow("Keep screen on", "Stop the screen turning off while a timer runs", st.keepAwake) {
                st.keepAwake = it
            }
        )

        // ---------------- OTHER ----------------
        col.addView(section("OTHER"))
        col.addView(clickRow("Reset settings", subText("Put every option back to normal")) {
            st.resetAll()
            toast("Settings reset")
            recreate()
        })

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0A0A0F.toInt())
        scroll.isFillViewport = true
        scroll.fitsSystemWindows = true
        scroll.addView(col)
        setContentView(scroll)
    }

    // ---- small UI helpers ------------------------------------------------------------------

    private fun indexOf(values: IntArray, value: Int, fallback: Int): Int {
        val i = values.indexOf(value)
        return if (i >= 0) i else fallback
    }

    private fun header(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(20), dp(8))

        val back = TextView(this)
        back.text = "←"
        back.textSize = 26f
        back.setTextColor(yellow)
        back.gravity = Gravity.CENTER
        back.setOnClickListener { finish() }
        row.addView(back, LinearLayout.LayoutParams(dp(52), dp(52)))

        val title = TextView(this)
        title.text = "SETTINGS"
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.3f
        title.setTextColor(yellow)
        row.addView(title)
        return row
    }

    private fun section(text: String): View {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.25f
        tv.setTextColor(yellow)
        tv.setPadding(dp(20), dp(24), dp(20), dp(6))
        return tv
    }

    private fun titleText(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 16f
        tv.setTextColor(white)
        return tv
    }

    private fun subText(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setTextColor(muted)
        tv.setPadding(0, dp(2), 0, 0)
        return tv
    }

    private fun clickRow(title: String, sub: TextView, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(14), dp(20), dp(14))
        box.addView(titleText(title))
        box.addView(sub)
        box.setOnClickListener { onClick() }
        return box
    }

    private fun switchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(titleText(title))
        texts.addView(subText(sub))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(20), dp(14))
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        return row
    }

    private fun volumeRow(): View {
        volLabel = subText("Volume " + st.volume + "% of your phone's alarm volume")
        val seek = SeekBar(this)
        seek.max = 100
        seek.progress = st.volume
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = if (progress < 10) 10 else progress
                volLabel.text = "Volume " + v + "% of your phone's alarm volume"
                if (fromUser) st.volume = v
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(14), dp(20), dp(10))
        box.addView(titleText("Alarm volume"))
        box.addView(volLabel)
        box.addView(seek)
        return box
    }

    private fun choose(title: String, labels: Array<String>, selected: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this, R.style.BatDialog)
            .setTitle(title)
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                onPick(which)
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    // ---- choosing the music ----------------------------------------------------------------

    private fun pickRingtone() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
        i.putExtra(
            RingtoneManager.EXTRA_RINGTONE_TYPE,
            RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_NOTIFICATION
        )
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm sound")
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
        val existing = st.soundUri
        if (existing != null) {
            i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existing))
        }
        try {
            startActivityForResult(i, REQ_RING)
        } catch (e: Exception) {
            toast("No ringtone picker found on this phone")
        }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_FILE)
        } catch (e: Exception) {
            toast("No file picker found on this phone")
        }
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            val c = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (c != null) {
                if (c.moveToFirst()) name = c.getString(0)
                c.close()
            }
        } catch (e: Exception) {
        }
        return name ?: "Music file"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return

        if (requestCode == REQ_RING) {
            val uri = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI) ?: return
            var name = "Ringtone"
            try {
                name = RingtoneManager.getRingtone(this, uri).getTitle(this)
            } catch (e: Exception) {
            }
            st.soundUri = uri.toString()
            st.soundName = name
            soundSub.text = name
        } else if (requestCode == REQ_FILE) {
            val uri = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            val name = queryName(uri)
            st.soundUri = uri.toString()
            st.soundName = name
            soundSub.text = name
        }
    }

    companion object {
        private const val REQ_RING = 101
        private const val REQ_FILE = 102
    }
}
