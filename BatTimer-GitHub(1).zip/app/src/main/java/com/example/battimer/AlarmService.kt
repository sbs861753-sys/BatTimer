package com.example.battimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Plays the chosen alarm music when the countdown ends (loops until the ring time is over or
 * the user taps STOP). Runs as a foreground service so Android does not kill it.
 */
class AlarmService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var camManager: CameraManager? = null
    private var torchId: String? = null
    private var torchOn = false
    private var flashing = false
    private var testMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> endRinging(true)
            ACTION_SNOOZE -> {
                TimerActions.snooze(this)
                endRinging(true)
            }
            ACTION_TEST -> startRinging(true)
            else -> startRinging(false)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopEffects()
        super.onDestroy()
    }

    // ---- start / stop ----------------------------------------------------------------------

    private fun startRinging(test: Boolean) {
        val s = Settings.get(this)
        testMode = test
        ensureChannel()
        ServiceCompat.startForeground(
            this, TimerActions.NOTIF_ID, buildNotification(true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )

        handler.removeCallbacksAndMessages(null)
        stopEffects()
        ringing = true

        playSound(s)
        if (s.vibrate) startVibration()
        if (s.flash) startFlash()

        val secs = if (test) 6 else s.ringSeconds
        if (secs > 0) handler.postDelayed({ finishAuto() }, secs * 1000L)
    }

    /** Ring time is over: stop the noise but leave a normal "time's up" notification behind. */
    private fun finishAuto() {
        stopEffects()
        if (testMode) {
            endRinging(true)
            return
        }
        stopForeground(STOP_FOREGROUND_DETACH)
        getSystemService(NotificationManager::class.java)
            .notify(TimerActions.NOTIF_ID, buildNotification(false))
        stopSelf()
    }

    private fun endRinging(removeNotification: Boolean) {
        handler.removeCallbacksAndMessages(null)
        stopEffects()
        stopForeground(if (removeNotification) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun stopEffects() {
        ringing = false
        flashing = false
        try {
            if (torchOn) camManager?.setTorchMode(torchId!!, false)
        } catch (e: Exception) {
        }
        torchOn = false
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
        }
        vibrator = null
        val p = player
        if (p != null) {
            try {
                p.stop()
            } catch (e: Exception) {
            }
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
        player = null
    }

    // ---- sound -----------------------------------------------------------------------------

    private fun playSound(s: Settings) {
        val vol = s.volume.coerceIn(10, 100) / 100f
        val chosen = s.soundUri?.let { Uri.parse(it) }
        if (chosen != null && tryPlay(chosen, s.fadeIn, vol)) return

        // The chosen file is missing or unreadable: fall back to the phone's own sounds.
        val types = intArrayOf(
            RingtoneManager.TYPE_ALARM,
            RingtoneManager.TYPE_NOTIFICATION,
            RingtoneManager.TYPE_RINGTONE
        )
        for (t in types) {
            val u = RingtoneManager.getDefaultUri(t) ?: continue
            if (tryPlay(u, s.fadeIn, vol)) return
        }
    }

    private fun tryPlay(uri: Uri, fade: Boolean, vol: Float): Boolean {
        var created: MediaPlayer? = null
        return try {
            val mp = MediaPlayer()
            created = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(this, uri)
            mp.isLooping = true
            val startVol = if (fade) 0f else vol
            mp.setVolume(startVol, startVol)
            mp.prepare()
            mp.start()
            player = mp
            if (fade) fadeIn(mp, vol)
            true
        } catch (e: Exception) {
            try {
                created?.release()
            } catch (e2: Exception) {
            }
            false
        }
    }

    /** Volume rises slowly over 6 seconds so the alarm does not shock you. */
    private fun fadeIn(mp: MediaPlayer, target: Float) {
        val steps = 60
        var step = 0
        val tick = object : Runnable {
            override fun run() {
                if (player !== mp) return
                step++
                val v = target * step / steps
                try {
                    mp.setVolume(v, v)
                } catch (e: Exception) {
                    return
                }
                if (step < steps) handler.postDelayed(this, 100)
            }
        }
        handler.postDelayed(tick, 100)
    }

    // ---- vibration + Bat-Signal torch ------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun startVibration() {
        try {
            val v = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator = v
            v.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 500, 400, 500, 400, 900, 1000), 0)
            )
        } catch (e: Exception) {
        }
    }

    private fun startFlash() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            camManager = cm
            torchId = id
            torchOn = false
            flashing = true
            handler.post(flashTick)
        } catch (e: Exception) {
            flashing = false
        }
    }

    private val flashTick = object : Runnable {
        override fun run() {
            if (!flashing) return
            torchOn = !torchOn
            try {
                camManager?.setTorchMode(torchId!!, torchOn)
            } catch (e: Exception) {
                flashing = false
                return
            }
            handler.postDelayed(this, 450)
        }
    }

    // ---- notification ----------------------------------------------------------------------

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Timer alarm", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shown while the timer alarm is ringing"
                setSound(null, null)
                enableVibration(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun actionIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, AlarmService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildNotification(ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bat)
            .setContentTitle(if (testMode) "Test alarm" else "The Bat-Signal is lit")
            .setContentText(
                if (testMode) "This is how your alarm will sound."
                else "Time's up. Your countdown has finished."
            )
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setOnlyAlertOnce(true)
        if (ongoing) {
            b.addAction(0, "STOP", actionIntent(ACTION_STOP, 21))
            if (!testMode) {
                b.addAction(0, "+" + Settings.get(this).snoozeMin + " MIN", actionIntent(ACTION_SNOOZE, 22))
            }
        }
        return b.build()
    }

    companion object {
        const val ACTION_RING = "com.example.battimer.ALARM_RING"
        const val ACTION_STOP = "com.example.battimer.ALARM_STOP"
        const val ACTION_SNOOZE = "com.example.battimer.ALARM_SNOOZE"
        const val ACTION_TEST = "com.example.battimer.ALARM_TEST"
        private const val CHANNEL_ID = "bat_alarm_silent_v2"

        /** True while the alarm sound is playing (read by the main screen). */
        @Volatile
        var ringing = false

        fun start(ctx: Context, test: Boolean = false) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, AlarmService::class.java)
                    .setAction(if (test) ACTION_TEST else ACTION_RING)
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AlarmService::class.java))
        }
    }
}
