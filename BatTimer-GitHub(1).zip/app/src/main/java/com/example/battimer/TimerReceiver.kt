package com.example.battimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TimerReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val s = TimerStore.get(ctx)
        when (intent.action) {
            TimerActions.ACTION_DONE -> {
                // Ignore a stale alarm (e.g. the timer was paused/reset just before it fired).
                if (s.state == TState.RUNNING && s.remainingMs() > 1500L) return
                if (s.state == TState.RUNNING) s.finish()
                if (s.state == TState.DONE) {
                    ring(ctx)
                    TimerActions.refreshWidgets(ctx)
                }
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                if (s.state == TState.RUNNING) {
                    if (s.remainingMs() > 0L) {
                        TimerActions.schedule(ctx, s.endAtMs)
                    } else {
                        s.finish()
                        ring(ctx)
                    }
                }
                // Chronometer bases are relative to boot time, so widgets must be rebuilt.
                TimerActions.refreshWidgets(ctx)
            }
        }
    }

    /** Play the chosen music; if Android refuses to start the player, show a normal notification. */
    private fun ring(ctx: Context) {
        try {
            AlarmService.start(ctx)
        } catch (e: Exception) {
            TimerActions.notifyDone(ctx)
        }
    }
}
