package com.example.battimer

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

/** Everything that changes timer state goes through here so alarm + widgets never drift apart. */
object TimerActions {

    const val ACTION_DONE = "com.example.battimer.TIMER_DONE"
    const val NOTIF_ID = 7
    private const val CHANNEL_ID = "bat_timer_done_v1"

    fun toggle(ctx: Context) {
        when (TimerStore.get(ctx).state) {
            TState.RUNNING -> pause(ctx)
            else -> start(ctx)
        }
    }

    fun start(ctx: Context) {
        val s = TimerStore.get(ctx)
        if (s.state == TState.RUNNING) return
        s.start()
        schedule(ctx, s.endAtMs)
        AlarmService.stop(ctx)
        cancelNotification(ctx)
        refreshWidgets(ctx)
    }

    fun pause(ctx: Context) {
        TimerStore.get(ctx).pause()
        cancelAlarm(ctx)
        refreshWidgets(ctx)
    }

    fun reset(ctx: Context) {
        TimerStore.get(ctx).reset()
        cancelAlarm(ctx)
        AlarmService.stop(ctx)
        cancelNotification(ctx)
        refreshWidgets(ctx)
    }

    fun setTotal(ctx: Context, ms: Long) {
        TimerStore.get(ctx).setTotal(ms)
        cancelAlarm(ctx)
        AlarmService.stop(ctx)
        cancelNotification(ctx)
        refreshWidgets(ctx)
    }

    /** Start a short extra countdown after the alarm (the "+5 MIN" button). */
    fun snooze(ctx: Context) {
        val s = TimerStore.get(ctx)
        s.snooze(Settings.get(ctx).snoozeMin * 60_000L)
        schedule(ctx, s.endAtMs)
        cancelNotification(ctx)
        refreshWidgets(ctx)
    }

    fun refreshWidgets(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, TimerWidget::class.java))
        if (ids.isNotEmpty()) TimerWidget.update(ctx, mgr, ids)
    }

    // ---- alarm -----------------------------------------------------------------------------

    private fun alarmIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, TimerReceiver::class.java).setAction(ACTION_DONE)
        return PendingIntent.getBroadcast(
            ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(ctx: Context, atMs: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(ctx)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        }
    }

    private fun cancelAlarm(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx))
    }

    // ---- plain notification (backup, used only if the alarm service cannot start) ----------

    fun notifyDone(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val channel = NotificationChannel(
                CHANNEL_ID, "Timer finished (backup)", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Used if the alarm player cannot start"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 800)
            }
            nm.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bat)
            .setContentTitle("The Bat-Signal is lit")
            .setContentText("Time's up. Your countdown has finished.")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_ID, n)
    }

    fun cancelNotification(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }
}
