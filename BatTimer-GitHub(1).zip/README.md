# Bat Timer 1.1

A Batman-themed countdown timer for Android with a live home-screen widget.

## Features
- Animated Bat-Signal ring, strobing and shaking when time is up.
- Home-screen widget (4x2): live countdown, play/pause, reset.
- **Timer up to 99 days** (Days / Hours / Minutes / Seconds picker).
- **Choose your alarm music**: default alarm, any phone ringtone, or any music file from your phone.
- **Settings screen** (gear icon, top right):
  - Alarm sound, Test alarm button
  - Ring for 10 sec / 30 sec / 1 min / 2 min / 5 min / until you stop it
  - Alarm volume, gentle fade-in, vibrate
  - Bat-Signal flash (phone torch blinks while the alarm rings)
  - Snooze length (the +N MIN button on the alarm notification)
  - Keep screen on while a timer runs
  - Reset settings
- STOP and +N MIN buttons right on the alarm notification.

## Build
Use the GitHub Actions workflow (.github/workflows/build.yml), or open the folder in Android Studio.

## Notes
- Alarm volume follows your phone's ALARM volume. The slider is a percentage of it.
- Music files are played from where they are stored. If you move or delete the file, the phone's default alarm plays instead.
- The widget shows hours instead of days when more than 24 hours are left (e.g. 50:00:00).
