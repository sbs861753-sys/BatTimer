# Bat Timer

A Batman-themed countdown timer for Android (Kotlin, one tiny dependency) with a live home-screen widget.

## Features
- **Animated Bat-Signal ring**: the ring eases smoothly every frame, a glowing head eats the ring, ticks go dark as time passes, the signal breathes, and it shakes and strobes when time is up.
- **Home-screen widget** (4x2, resizable): live count-down, play/pause and reset buttons, tap the body to open the app. It uses a native count-down Chronometer, so it ticks every second without a service or battery drain.
- **Reliable alarm**: an exact alarm plus a high-priority alarm-sound notification when the timer ends, even if the app is closed. The alarm is restored after a reboot.
- Presets (1, 5, 10, 25 min, 1 hour) and a custom hours/minutes/seconds picker.
- State is saved, so the timer keeps running if the app is killed.

## Build
1. Open this folder in **Android Studio** (Koala or newer). Let Gradle sync; it will download Gradle 8.7.
2. Run on a device or emulator (Android 8.0+, API 26).
3. Add the widget: long-press the home screen, Widgets, Bat Timer.

To make an APK: Build, Build Bundle(s) / APK(s), Build APK(s).

## Where to customize
| What | Where |
|---|---|
| Colors | `res/values/colors.xml` and the `yellow` / `amber` values at the top of `BatTimerView.kt` |
| Default time | `TimerStore.kt` (`5 * 60_000L`) |
| Presets | `activity_main.xml` (chips) and `MainActivity.kt` (the `chips` list) |
| Bat emblem | `BatShape.PATH` in `BatTimerView.kt` and the same path in `res/drawable/ic_bat.xml` and `ic_launcher_foreground.xml` |
| Alarm sound | `TimerActions.notifyDone` |
| Ring animation feel | `BatTimerView.onDraw` (easing speed is the `9f` in `exp(-dt * 9f)`) |

## Notes
- The bat shape is a simple hand-drawn path, not the official logo. Swap in your own path data if you want a different look.
- On Android 13+ the app asks for notification permission on first launch. Without it the alarm notification will not show.
- The widget updates instantly on every tap, but the Chronometer display itself is drawn by the launcher, so its font can look slightly different between launchers.
