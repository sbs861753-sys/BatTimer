package com.example.battimer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: TimerStore
    private lateinit var timerView: BatTimerView
    private lateinit var btnStart: TextView
    private lateinit var chips: List<Pair<TextView, Long>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = TimerStore.get(this)
        timerView = findViewById(R.id.timer_view)
        btnStart = findViewById(R.id.btn_start)

        timerView.store = store
        timerView.onStateChanged = { refreshUi() }
        timerView.setOnClickListener { toggle(it) }
        btnStart.setOnClickListener { toggle(it) }

        findViewById<View>(R.id.btn_reset).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            TimerActions.reset(this)
            refreshUi()
        }
        findViewById<View>(R.id.btn_set).setOnClickListener { showSetDialog() }

        chips = listOf(
            R.id.chip_1 to 60L,
            R.id.chip_5 to 300L,
            R.id.chip_10 to 600L,
            R.id.chip_25 to 1500L,
            R.id.chip_60 to 3600L
        ).map { (id, sec) -> findViewById<TextView>(id) to sec * 1000L }

        chips.forEach { (view, ms) ->
            view.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                TimerActions.setTotal(this, ms)
                refreshUi()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        TimerActions.refreshWidgets(this)
        refreshUi()
    }

    private fun toggle(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        TimerActions.toggle(this)
        refreshUi()
    }

    private fun refreshUi() {
        btnStart.text = when (store.state) {
            TState.IDLE -> "START"
            TState.RUNNING -> "PAUSE"
            TState.PAUSED -> "RESUME"
            TState.DONE -> "RESTART"
        }
        chips.forEach { (view, ms) -> view.isSelected = ms == store.totalMs }
    }

    private fun showSetDialog() {
        val sec = (store.totalMs / 1000L).toInt()

        fun picker(max: Int, value: Int) = NumberPicker(this).apply {
            minValue = 0
            maxValue = max
            this.value = value
            wrapSelectorWheel = true
            setFormatter { "%02d".format(it) }
        }

        val h = picker(23, sec / 3600)
        val m = picker(59, (sec % 3600) / 60)
        val s = picker(59, sec % 60)

        fun column(p: NumberPicker, label: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(p)
            addView(TextView(context).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(0xFF8A8A96.toInt())
            })
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad / 2)
            addView(column(h, "HOURS"))
            addView(column(m, "MINUTES"))
            addView(column(s, "SECONDS"))
        }

        AlertDialog.Builder(this, R.style.BatDialog)
            .setTitle("Set countdown")
            .setView(row)
            .setPositiveButton("SET") { _, _ ->
                val total = h.value * 3600L + m.value * 60L + s.value
                if (total <= 0L) {
                    Toast.makeText(this, "Pick a time above zero", Toast.LENGTH_SHORT).show()
                } else {
                    TimerActions.setTotal(this, total * 1000L)
                    refreshUi()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }
}
