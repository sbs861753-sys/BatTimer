package com.example.battimer

import android.content.Context
import kotlin.math.max

enum class TState { IDLE, RUNNING, PAUSED, DONE }

/**
 * Single source of truth for the timer. Shared by the activity, the widget and the alarm
 * receiver, and persisted in SharedPreferences so it survives the app being killed.
 */
class TimerStore private constructor(context: Context) {

    private val prefs = context.getSharedPreferences("bat_timer", Context.MODE_PRIVATE)

    /** Length of the countdown (default: 5 minutes). */
    var totalMs: Long = prefs.getLong("total", 5 * 60_000L)
        private set

    var state: TState =
        runCatching { TState.valueOf(prefs.getString("state", "IDLE")!!) }.getOrDefault(TState.IDLE)
        private set

    /** Wall-clock time (ms) at which the running countdown reaches zero. */
    var endAtMs: Long = prefs.getLong("end", 0L)
        private set

    private var leftMs: Long = prefs.getLong("left", totalMs)

    fun remainingMs(): Long = when (state) {
        TState.RUNNING -> max(0L, endAtMs - System.currentTimeMillis())
        TState.DONE -> 0L
        else -> leftMs
    }

    fun setTotal(ms: Long) {
        totalMs = ms
        leftMs = ms
        endAtMs = 0L
        state = TState.IDLE
        save()
    }

    fun start() {
        if (state == TState.RUNNING) return
        if (state == TState.DONE || leftMs <= 0L) leftMs = totalMs
        endAtMs = System.currentTimeMillis() + leftMs
        state = TState.RUNNING
        save()
    }

    fun pause() {
        if (state != TState.RUNNING) return
        leftMs = remainingMs()
        state = TState.PAUSED
        save()
    }

    fun reset() {
        leftMs = totalMs
        endAtMs = 0L
        state = TState.IDLE
        save()
    }

    fun finish() {
        leftMs = 0L
        state = TState.DONE
        save()
    }

    private fun save() {
        prefs.edit()
            .putLong("total", totalMs)
            .putString("state", state.name)
            .putLong("end", endAtMs)
            .putLong("left", leftMs)
            .apply()
    }

    companion object {
        @Volatile
        private var instance: TimerStore? = null

        fun get(context: Context): TimerStore =
            instance ?: synchronized(this) {
                instance ?: TimerStore(context.applicationContext).also { instance = it }
            }
    }
}
