package com.example.battimer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews

class TimerWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        update(ctx, mgr, ids)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            ACTION_TOGGLE -> TimerActions.toggle(ctx)
            ACTION_RESET -> TimerActions.reset(ctx)
        }
        super.onReceive(ctx, intent)
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.battimer.WIDGET_TOGGLE"
        const val ACTION_RESET = "com.example.battimer.WIDGET_RESET"

        fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val s = TimerStore.get(ctx)
            if (s.state == TState.RUNNING && s.remainingMs() <= 0L) s.finish()

            val state = s.state
            val remaining = s.remainingMs()
            val rv = RemoteViews(ctx.packageName, R.layout.widget_timer)

            // A native count-down Chronometer ticks every second on its own, so the widget
            // stays live without a service or wake-ups. The +900ms makes it show the same
            // rounded-up seconds as the in-app ring.
            val base = SystemClock.elapsedRealtime() + if (state == TState.DONE) 0L else remaining + 900L
            rv.setChronometerCountDown(R.id.w_time, true)
            rv.setChronometer(R.id.w_time, base, null, state == TState.RUNNING)

            rv.setTextViewText(
                R.id.w_status,
                when (state) {
                    TState.IDLE -> "READY"
                    TState.RUNNING -> "ON PATROL"
                    TState.PAUSED -> "STANDBY"
                    TState.DONE -> "TIME'S UP"
                }
            )
            rv.setImageViewResource(
                R.id.w_toggle,
                if (state == TState.RUNNING) R.drawable.ic_pause else R.drawable.ic_play
            )

            rv.setOnClickPendingIntent(R.id.w_toggle, broadcast(ctx, ACTION_TOGGLE, 10))
            rv.setOnClickPendingIntent(R.id.w_reset, broadcast(ctx, ACTION_RESET, 11))
            rv.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(
                    ctx, 12, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            mgr.updateAppWidget(ids, rv)
        }

        private fun broadcast(ctx: Context, action: String, code: Int): PendingIntent {
            val i = Intent(ctx, TimerWidget::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
